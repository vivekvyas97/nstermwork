import java.util.*;
class OnePad
{
	public static void main(String args[])throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the message:");
		String plain_txt=sc.nextLine();
		char[] pad=new char[plain_txt.length()];
		Random ran = new Random(); 
		for(int i=0;i<plain_txt.length();i++)
		{
			int asci=ran.nextInt(123);
			if(asci<=127)
			{
				pad[i]=(char)asci;
			}
			else
				i--;
		}
		System.out.println(pad);
		char[] msg=plain_txt.toCharArray();
		char[] cipher_txt=new char[msg.length];
		for(int i=0;i<msg.length;i++)
		{
			cipher_txt[i]=(char)(msg[i]^pad[i]);
		}
		System.out.print("cipher text:");
		System.out.print(cipher_txt);
		char[] original_txt=new char[msg.length];
		for(int i=0;i<msg.length;i++)
		{
			original_txt[i]=(char)(pad[i]^cipher_txt[i]);
		}
		System.out.print("\noriginal text:");
		System.out.print(original_txt);
	}
}